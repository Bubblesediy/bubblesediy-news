import type {Article} from "@/types";
// Replace with real content, a CMS or a database. Set demo:false for real stories.
const body=(t:string)=>["DEMO ARTICLE — Replace before publication.",`This is fictional placeholder text for “${t}”. It exists only to test layout, typography and navigation.`,"Replace this entire entry with an original, verified story, credit your sources, and use properly licensed images."];
const mk=(i:number,category:string,title:string,keywords:string[]):Article=>{const slug="demo-"+title.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/-$/,"");const d=`2026-09-${String(30-i).padStart(2,"0")}T10:00:00+05:30`;
return{id:String(i+1),title:"DEMO: "+title,slug,category,excerpt:`DEMO ARTICLE — Replace before publication. Placeholder summary about ${title.toLowerCase()}.`,content:body(title),author:"BubblesEdiy News Desk",publishedAt:d,updatedAt:d,image:`/images/${category.toLowerCase().replace(/ /g,"-")}.svg`,keywords,demo:true}};
export const ARTICLES:Article[]=[
mk(0,"Technology","Sample Story About a Fictional Gadget Launch",["gadget","demo"]),
mk(1,"India","Sample Story About a Fictional Policy Debate",["policy"]),
mk(2,"Tamil Nadu","Sample Story About a Fictional Harvest Festival",["festival"]),
mk(3,"Chennai","Sample Story About a Fictional Metro Extension",["metro","transport"]),
mk(4,"World","Sample Story About a Fictional Climate Summit",["climate"]),
mk(5,"Business","Sample Story About a Fictional Startup Funding Round",["startup"]),
mk(6,"Sports","Sample Story About a Fictional Cricket Final",["cricket"]),
mk(7,"Entertainment","Sample Story About a Fictional Film Premiere",["film"]),
mk(8,"Science","Sample Story About a Fictional Space Probe",["space"]),
mk(9,"Lifestyle","Sample Story About Fictional Healthy Eating Habits",["food","health"]),
].sort((a,b)=>+new Date(b.publishedAt)-+new Date(a.publishedAt));
