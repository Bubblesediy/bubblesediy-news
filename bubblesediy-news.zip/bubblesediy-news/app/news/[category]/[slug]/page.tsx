import Link from "next/link";import type {Metadata} from "next";import {ARTICLES,url,fmt,catSlug,abs,slugify} from "@/lib/content";import {Card,Ad,JsonLd,crumbs} from "@/components/Ui";import {SITE,AUTHORS} from "@/data/site";
export const dynamicParams=false;
export const generateStaticParams=()=>ARTICLES.map(a=>({category:catSlug(a.category),slug:a.slug}));
const get=(s:string)=>ARTICLES.findIndex(a=>a.slug===s);
export function generateMetadata({params}:{params:{slug:string}}):Metadata{const a=ARTICLES[get(params.slug)];const u=url(a);const img=abs(a.image,SITE.url);
return{title:a.title,description:a.excerpt,alternates:{canonical:SITE.url+u},robots:a.demo?{index:false,follow:true}:undefined,openGraph:{type:"article",title:a.title,description:a.excerpt,url:SITE.url+u,images:[img],publishedTime:a.publishedAt,modifiedTime:a.updatedAt,authors:[a.author],section:a.category},twitter:{card:"summary_large_image",title:a.title,description:a.excerpt,images:[img]}}}
export default function Page({params}:{params:{slug:string}}){const i=get(params.slug);const a=ARTICLES[i];const prev=ARTICLES[i+1],next=ARTICLES[i-1];const rel=ARTICLES.filter(x=>x.id!==a.id).slice(0,3);const au=slugify(a.author);const cs=catSlug(a.category);
const share=encodeURIComponent(SITE.url+url(a));
return(<article className="mx-auto max-w-3xl">
{!a.demo&&<JsonLd d={{"@context":"https://schema.org","@type":"NewsArticle",headline:a.title,description:a.excerpt,image:[abs(a.image,SITE.url)],datePublished:a.publishedAt,dateModified:a.updatedAt,articleSection:a.category,mainEntityOfPage:SITE.url+url(a),author:{"@type":"Person",name:a.author,url:`${SITE.url}/author/${au}`},publisher:{"@type":"Organization",name:SITE.name}}}/>}
<JsonLd d={crumbs([["Home","/"],[a.category,`/category/${cs}`],[a.title,url(a)]])}/>
<nav aria-label="Breadcrumb" className="text-sm text-mute"><Link href="/">Home</Link> / <Link href={`/category/${cs}`}>{a.category}</Link> / <span aria-current="page">{a.title}</span></nav>
{a.demo&&<p role="note" className="mt-3 border border-accent p-2 font-semibold">DEMO ARTICLE — Replace before publication</p>}
<p className="mt-4 font-semibold text-accent">{a.category}</p><h1 className="text-4xl font-bold md:text-5xl">{a.title}</h1><p className="mt-3 text-xl text-mute">{a.excerpt}</p>
<p className="mt-4 text-sm">By <Link className="underline" href={`/author/${au}`}>{a.author}</Link> · Published <time dateTime={a.publishedAt}>{fmt(a.publishedAt)}</time> · Updated <time dateTime={a.updatedAt}>{fmt(a.updatedAt)}</time></p>
<img src={a.image} alt={`Illustration for ${a.title}`} width={1200} height={675} className="my-5 aspect-video w-full rounded object-cover"/>
<div className="prose">{a.content.map((p,k)=><p key={k}>{p}</p>)}</div><Ad/>
<div className="flex flex-wrap gap-2" aria-label="Share"><a className="min-h-11 rounded border border-line px-3 py-2" href={`https://twitter.com/intent/tweet?url=${share}`} rel="noopener noreferrer">Share on X</a><a className="min-h-11 rounded border border-line px-3 py-2" href={`https://www.facebook.com/sharer/sharer.php?u=${share}`} rel="noopener noreferrer">Facebook</a><a className="min-h-11 rounded border border-line px-3 py-2" href={`https://wa.me/?text=${share}`} rel="noopener noreferrer">WhatsApp</a></div>
<nav aria-label="Article navigation" className="my-8 grid gap-3 sm:grid-cols-2">{prev&&<Link className="rounded border border-line p-3" href={url(prev)}>Previous: {prev.title}</Link>}{next&&<Link className="rounded border border-line p-3 sm:text-right" href={url(next)}>Next: {next.title}</Link>}</nav>
<section><h2 className="text-2xl font-bold">About the Author</h2><p className="mt-2 text-mute">{AUTHORS.find(x=>x.slug===au)?.bio} <Link className="underline" href={`/author/${au}`}>Author profile</Link></p></section>
<section className="mt-8"><h2 className="mb-3 text-2xl font-bold">Related News</h2><div className="grid gap-4 sm:grid-cols-3">{rel.map(r=><Card key={r.id} a={r}/>)}</div></section></article>)}
