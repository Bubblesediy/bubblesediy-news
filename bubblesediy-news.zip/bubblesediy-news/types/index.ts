export type Article={id:string;title:string;slug:string;category:string;excerpt:string;content:string[];author:string;publishedAt:string;updatedAt:string;image:string;keywords:string[];demo:boolean};
